plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "ru.nova.vpn"
    compileSdk = 35
    defaultConfig {
        applicationId = "ru.nova.vpn"
        minSdk = 26
        targetSdk = 35
        versionCode = 2
        versionName = "0.2.0"
    }
}
dependencies {
    // Official Android sing-box library. Gradle downloads its AAR during build.
    implementation("com.github.singbox-android:libbox:1.14.0")
}
