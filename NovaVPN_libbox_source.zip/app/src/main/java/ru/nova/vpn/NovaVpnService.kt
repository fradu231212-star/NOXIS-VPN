package ru.nova.vpn

import android.net.VpnService

/**
 * Android VPN service placeholder.
 *
 * The libbox AAR is declared in Gradle, but its CommandServer/PlatformInterface
 * lifecycle bridge is not wired yet. Do not present this service as a working tunnel.
 */
class NovaVpnService : VpnService()
