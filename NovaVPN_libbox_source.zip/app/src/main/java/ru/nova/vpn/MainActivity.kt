package ru.nova.vpn

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.*
import android.content.Context

class MainActivity : Activity() {
    private lateinit var keyInput: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("nova", Context.MODE_PRIVATE)

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 36, 24, 24)
            setBackgroundColor(Color.rgb(13, 17, 30))
        }
        fun title(t: String, size: Float) = TextView(this).apply {
            text = t; textSize = size; setTextColor(Color.WHITE)
        }
        page.addView(title("NOVA VPN", 30f))
        page.addView(title("Клиент на базе sing-box libbox", 15f))

        keyInput = EditText(this).apply {
            hint = "Вставь ссылку сервера"
            setHintTextColor(Color.LTGRAY); setTextColor(Color.WHITE)
            minLines = 3; gravity = Gravity.TOP
            setPadding(12, 12, 12, 12)
            setBackgroundColor(Color.rgb(35, 43, 63))
        }
        page.addView(keyInput, LinearLayout.LayoutParams(-1, 130).apply { topMargin = 24 })

        val save = Button(this).apply { text = "Сохранить конфигурацию" }
        page.addView(save)
        val savedLabel = title(
            if (prefs.getString("profile", "").isNullOrBlank()) "Конфигурация не добавлена"
            else "Конфигурация сохранена на устройстве", 14f
        )
        page.addView(savedLabel)

        val notice = title(
            "Ядро libbox добавлено как зависимость проекта. Но управление ядром и Android VPN-туннелем ещё не реализовано: кнопка подключения намеренно не запускает фиктивное соединение.",
            13f
        )
        notice.setPadding(0, 22, 0, 18)
        page.addView(notice)

        save.setOnClickListener {
            val value = keyInput.text.toString().trim()
            val schemes = listOf("vless://", "vmess://", "trojan://", "ss://",
                "hysteria2://", "hy2://", "tuic://", "wireguard://", "wg://")
            if (schemes.none { value.startsWith(it, ignoreCase = true) }) {
                Toast.makeText(this, "Неизвестный формат ссылки", Toast.LENGTH_SHORT).show()
            } else {
                prefs.edit().putString("profile", value).apply()
                savedLabel.text = "Конфигурация сохранена на устройстве"
                keyInput.text.clear()
                Toast.makeText(this, "Сохранено", Toast.LENGTH_SHORT).show()
            }
        }
        page.addView(ScrollView(this).apply { addView(LinearLayout(this@MainActivity).apply {
            orientation = LinearLayout.VERTICAL
            addView(title("Поддерживаемые форматы зависят от сборки sing-box.", 13f))
        }) })
        setContentView(ScrollView(this).apply { addView(page) })
    }
}
